//
//  ListViewPackage.swift
//  DemoTest
//
//  Created by developer on 22/04/24.
//

import SwiftUI
import Alamofire

public struct ListView: View {
    var emails: [String]
    var didSelectEmail: (String) -> Void
    
    public init(emails: [String], didSelectEmail: @escaping (String) -> Void) {
        self.emails = emails
        self.didSelectEmail = didSelectEmail
    }
    
    public var body: some View {
        NavigationView {
            List(emails, id: \.self) { email in
                Button(action: {
                    didSelectEmail(email)
                }) {
                    Text(email)
                }
            }
            .navigationBarTitle("Emails")
        }
    }
}
